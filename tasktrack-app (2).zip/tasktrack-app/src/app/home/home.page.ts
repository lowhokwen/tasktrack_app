import { Component, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { 
  IonContent, 
  IonHeader, 
  IonTitle, 
  IonToolbar, 
  IonButtons, 
  IonButton, 
  IonIcon,
  IonCard,
  IonCardHeader,
  IonCardTitle,
  IonCardSubtitle,
  IonCardContent,
  IonList,
  IonItem,
  IonLabel,
  IonInput,
  IonTextarea,
  IonSegment,
  IonSegmentButton,
  IonCheckbox,
  IonBadge,
  IonItemSliding,
  IonItemOptions,
  IonItemOption,
  IonSelect,
  IonSelectOption,
  IonToggle,
  IonGrid,
  IonRow,
  IonCol,
  ModalController,
  AlertController,
  ToastController
} from '@ionic/angular/standalone';
import { TaskService, Task } from '../services/task.service';
import { SimpleStorageService } from '../simple-storage.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    IonContent,
    IonHeader,
    IonTitle,
    IonToolbar,
    IonButtons,
    IonButton,
    IonIcon,
    IonCard,
    IonCardHeader,
    IonCardTitle,
    IonCardSubtitle,
    IonCardContent,
    IonList,
    IonItem,
    IonLabel,
    IonInput,
    IonTextarea,
    IonSegment,
    IonSegmentButton,
    IonCheckbox,
    IonBadge,
    IonItemSliding,
    IonItemOptions,
    IonItemOption,
    IonSelect,
    IonSelectOption,
    IonToggle,
    IonGrid,
    IonRow,
    IonCol
  ]
})
export class HomePage implements OnInit, OnDestroy {
  // Page Management
  currentPage: string = 'homepage';
  isLoggedIn: boolean = false;
  
  // Task Management
  tasks: Task[] = [];
  filteredTasks: Task[] = [];
  taskFilter: string = 'all';
  private tasksSubscription: Subscription = new Subscription();

  // Statistics
  pendingCount: number = 0;
  completedCount: number = 0;
  overdueCount: number = 0;

  // Forms Data
  loginData = {
    email: '',
    password: ''
  };

  newTask = {
    title: '',
    description: '',
    dueDate: '',
    priority: 'medium' as 'low' | 'medium' | 'high'
  };

  settings = {
    theme: 'light',
    notifications: true
  };

  constructor(
    private taskService: TaskService,
    private storageService: SimpleStorageService,  
    private modalController: ModalController,
    private alertController: AlertController,
    private toastController: ToastController
  ) {}

  async ngOnInit() {
    // Check if user was previously logged in from storage
    const savedLogin = await this.storageService.loadLoginState();
    if (savedLogin) {
      this.isLoggedIn = true;
      this.currentPage = 'homepage';
    }

    // Load settings from storage
    const savedSettings = await this.storageService.loadSettings();
    this.settings = { ...this.settings, ...savedSettings };

    // Subscribe to tasks only if logged in
    if (this.isLoggedIn) {
      this.subscribeToTasks();
    }
  }

  subscribeToTasks() {
    this.tasksSubscription = this.taskService.tasks$.subscribe(tasks => {
      this.tasks = tasks;
      this.updateStats(tasks);
      this.applyTaskFilter();
    });
  }

  async login() {
  // Simple demo login - in real app, integrate with Firebase Auth
    if (this.loginData.email && this.loginData.password) {
      this.isLoggedIn = true;
      this.currentPage = 'homepage';
      
      // Save login state to storage
      await this.storageService.saveLoginState(true);
      
      // Start listening to tasks after login
      this.subscribeToTasks();
      
      this.showToast('Login successful!', 'success');
      this.loginData = { email: '', password: '' };
    } else {
      this.showToast('Please enter email and password', 'warning');
    }
  }

  async logout() {
    this.isLoggedIn = false;
    this.currentPage = 'homepage';
    
    // Remove login state from storage
    await this.storageService.saveLoginState(false);
    
    // Unsubscribe from tasks
    this.tasksSubscription.unsubscribe();
    this.tasks = [];
    this.filteredTasks = [];
    
    this.showToast('Logged out successfully', 'success');
  }

  // Task Management
  addNewTask() {
    if (this.newTask.title.trim()) {
      this.taskService.addTask({
        title: this.newTask.title,
        description: this.newTask.description,
        dueDate: this.newTask.dueDate,
        priority: this.newTask.priority,
        status: 'pending'
      });

      this.showToast('Task added successfully!', 'success');
      this.clearForm();
      this.currentPage = 'task-list';
    }
  }

  clearForm() {
    this.newTask = {
      title: '',
      description: '',
      dueDate: '',
      priority: 'medium'
    };
  }

  // Task Actions
  toggleTaskStatus(task: Task) {
    if (task.id) {
      const newStatus = task.status === 'completed' ? 'pending' : 'completed';
      this.taskService.updateTask(task.id, { status: newStatus });
      
      const message = newStatus === 'completed' 
        ? 'Task completed! 🎉' 
        : 'Task marked as pending';
      this.showToast(message, 'success');
    }
  }

  async deleteTask(task: Task) {
    const alert = await this.alertController.create({
      header: 'Delete Task',
      message: `Are you sure you want to delete "${task.title}"?`,
      buttons: [
        {
          text: 'Cancel',
          role: 'cancel'
        },
        {
          text: 'Delete',
          role: 'destructive',
          handler: () => {
            if (task.id) {
              this.taskService.deleteTask(task.id);
              this.showToast('Task deleted', 'warning');
            }
          }
        }
      ]
    });

    await alert.present();
  }

  // Filtering
  applyTaskFilter() {
    if (this.taskFilter === 'all') {
      this.filteredTasks = this.tasks;
    } else {
      this.filteredTasks = this.tasks.filter(task => task.status === this.taskFilter);
    }
  }

  // Statistics
  updateStats(tasks: Task[]) {
    this.pendingCount = tasks.filter(t => t.status === 'pending').length;
    this.completedCount = tasks.filter(t => t.status === 'completed').length;
    this.overdueCount = tasks.filter(t => t.status === 'overdue').length;
  }

  // Utilities
  getPriorityColor(priority: string): string {
    switch (priority) {
      case 'high': return 'danger';
      case 'medium': return 'warning';
      case 'low': return 'success';
      default: return 'medium';
    }
  }

  getStatusColor(status: string): string {
    switch (status) {
      case 'pending': return 'warning';
      case 'completed': return 'success';
      case 'overdue': return 'danger';
      default: return 'medium';
    }
  }

  formatDate(dateString: string): string {
    if (!dateString) return '';
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
      month: 'short', 
      day: 'numeric',
      year: 'numeric'
    });
  }

  // Settings
  async applySettings() {
    // Save settings to storage
    await this.storageService.saveSettings(this.settings);
    this.showToast('Settings saved', 'success');
  }

  exportData() {
    const data = JSON.stringify(this.tasks, null, 2);
    const blob = new Blob([data], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'tasktrack-export.json';
    link.click();
    this.showToast('Data exported successfully', 'success');
  }

  async clearAllData() {
    const alert = await this.alertController.create({
      header: 'Clear All Data',
      message: 'This will delete ALL your tasks. This action cannot be undone!',
      buttons: [
        {
          text: 'Cancel',
          role: 'cancel'
        },
        {
          text: 'Clear All',
          role: 'destructive',
          handler: () => {
            // Delete all tasks
            this.tasks.forEach(task => {
              if (task.id) {
                this.taskService.deleteTask(task.id);
              }
            });
            this.showToast('All data cleared', 'warning');
          }
        }
      ]
    });

    await alert.present();
  }

  // UI Helpers
  async showToast(message: string, color: 'success' | 'warning' | 'danger' = 'success') {
    const toast = await this.toastController.create({
      message: message,
      duration: 2000,
      color: color,
      position: 'bottom'
    });
    await toast.present();
  }

  ngOnDestroy() {
    this.tasksSubscription.unsubscribe();
  }

    // Cache Management
  async viewCacheInfo() {
    const cachedTasks = await this.storageService.loadTasks();
    const lastUpdated = await this.storageService.getLastUpdateTime();
    
    const alert = await this.alertController.create({
      header: 'Cache Information',
      message: `
        <p><strong>Cached Tasks:</strong> ${cachedTasks.length}</p>
        <p><strong>Last Updated:</strong> ${lastUpdated ? new Date(lastUpdated).toLocaleString() : 'Never'}</p>
        <p><strong>Live Tasks:</strong> ${this.tasks.length}</p>
      `,
      buttons: ['OK']
    });

    await alert.present();
  }

  async clearCache() {
    const alert = await this.alertController.create({
      header: 'Clear Cache',
      message: 'This will clear all locally stored data. Your data in Firebase will remain safe.',
      buttons: [
        {
          text: 'Cancel',
          role: 'cancel'
        },
        {
          text: 'Clear Cache',
          handler: async () => {
            await this.storageService.clearCache();
            this.showToast('Cache cleared successfully', 'success');
          }
        }
      ]
    });

    await alert.present();
  }
}