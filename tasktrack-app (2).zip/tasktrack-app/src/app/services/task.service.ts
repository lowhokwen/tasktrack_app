import { Injectable } from '@angular/core';
import { db } from '../firebase.init';
import {
  collection,
  addDoc,
  doc,
  updateDoc,
  deleteDoc,
  onSnapshot,
  query,
  orderBy,
  DocumentData,
  CollectionReference
} from 'firebase/firestore';
import { BehaviorSubject } from 'rxjs';
import { StorageService } from '../storage.service';

export interface Task {
  id?: string;
  title: string;
  description: string;
  status: 'pending' | 'completed' | 'overdue';
  dueDate: string;
  priority: 'low' | 'medium' | 'high';
  createdAt: any;
  updatedAt: any;
}

@Injectable({
  providedIn: 'root'
})
export class TaskService {
  private tasksCollection: CollectionReference<DocumentData>;
  public tasks$ = new BehaviorSubject<Task[]>([]);
  private isInitialLoad = true;

  constructor(private storageService: StorageService) {
    this.tasksCollection = collection(db, 'tasks');
    this.initializeTasks();
  }

  // Initialize tasks with cache first, then real-time updates
  private async initializeTasks() {
    // First, load from cache for instant display
    const cachedTasks = await this.storageService.loadTasks();
    if (cachedTasks.length > 0) {
      this.tasks$.next(cachedTasks);
      console.log('Loaded tasks from cache:', cachedTasks.length);
    }

    // Then setup real-time listener
    this.setupRealtimeListener();
  }

  // Setup real-time Firestore listener
  private setupRealtimeListener() {
    const q = query(this.tasksCollection, orderBy('createdAt', 'desc'));
    
    onSnapshot(q, async (snapshot) => {
      const tasks: Task[] = [];
      snapshot.forEach((docSnap) => {
        tasks.push({
          id: docSnap.id,
          ...docSnap.data()
        } as Task);
      });

      // Update the BehaviorSubject
      this.tasks$.next(tasks);

      // Save to cache
      await this.storageService.saveTasks(tasks);

      // Show message for initial load
      if (this.isInitialLoad) {
        this.isInitialLoad = false;
        const cachedTasks = await this.storageService.loadTasks();
        if (cachedTasks.length > 0) {
          console.log('Now connected to live data. Cache was used for instant load.');
        }
      }
    }, async (error) => {
      console.error('Real-time listener error:', error);
      
      // If real-time fails, try to load from cache as fallback
      const cachedTasks = await this.storageService.loadTasks();
      if (cachedTasks.length > 0) {
        console.log('Using cached data due to connection issues');
        this.tasks$.next(cachedTasks);
      }
    });
  }

  // Create - Add new task
  async addTask(task: Omit<Task, 'id' | 'createdAt' | 'updatedAt'>) {
    try {
      const docRef = await addDoc(this.tasksCollection, {
        ...task,
        createdAt: new Date(),
        updatedAt: new Date()
      });
      return docRef.id;
    } catch (error) {
      console.error('Error adding task:', error);
      throw error;
    }
  }

  // Update - Update task
  async updateTask(id: string, data: Partial<Task>) {
    try {
      const docRef = doc(db, 'tasks', id);
      await updateDoc(docRef, {
        ...data,
        updatedAt: new Date()
      });
    } catch (error) {
      console.error('Error updating task:', error);
      throw error;
    }
  }

  // Delete - Delete task
  async deleteTask(id: string) {
    try {
      const docRef = doc(db, 'tasks', id);
      await deleteDoc(docRef);
    } catch (error) {
      console.error('Error deleting task:', error);
      throw error;
    }
  }

  // Get tasks by status
  getTasksByStatus(status: Task['status']): Task[] {
    return this.tasks$.value.filter(task => task.status === status);
  }

  // Force refresh from cache (for debugging)
  async refreshFromCache() {
    const cachedTasks = await this.storageService.loadTasks();
    this.tasks$.next(cachedTasks);
    return cachedTasks;
  }
}