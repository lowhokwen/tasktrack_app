import { Injectable } from '@angular/core';
import { Storage } from '@ionic/storage-angular';
import { Task } from './services/task.service';

@Injectable({
  providedIn: 'root'
})
export class StorageService {
  private _storage: Storage | null = null;

  constructor(private storage: Storage) {
    this.init();
  }

  async init() {
    // Create storage
    this._storage = await this.storage.create();
  }

  // Save tasks to local storage
  async saveTasks(tasks: Task[]): Promise<void> {
    if (this._storage) {
      await this._storage.set('tasks', tasks);
      await this._storage.set('tasks_last_updated', new Date().toISOString());
    }
  }

  // Load tasks from local storage
  async loadTasks(): Promise<Task[]> {
    if (this._storage) {
      const tasks = await this._storage.get('tasks');
      return tasks || [];
    }
    return [];
  }

  // Get last update time
  async getLastUpdateTime(): Promise<string> {
    if (this._storage) {
      return await this._storage.get('tasks_last_updated') || '';
    }
    return '';
  }

  // Clear all cached data
  async clearCache(): Promise<void> {
    if (this._storage) {
      await this._storage.remove('tasks');
      await this._storage.remove('tasks_last_updated');
    }
  }

  // Save user settings
  async saveSettings(settings: any): Promise<void> {
    if (this._storage) {
      await this._storage.set('user_settings', settings);
    }
  }

  // Load user settings
  async loadSettings(): Promise<any> {
    if (this._storage) {
      const settings = await this._storage.get('user_settings');
      return settings || {
        theme: 'light',
        notifications: true
      };
    }
    return {
      theme: 'light',
      notifications: true
    };
  }

  // Save login state
  async saveLoginState(isLoggedIn: boolean): Promise<void> {
    if (this._storage) {
      await this._storage.set('is_logged_in', isLoggedIn);
    }
  }

  // Load login state
  async loadLoginState(): Promise<boolean> {
    if (this._storage) {
      return await this._storage.get('is_logged_in') || false;
    }
    return false;
  }
}