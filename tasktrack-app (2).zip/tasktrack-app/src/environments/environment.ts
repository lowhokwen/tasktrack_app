export const environment = {
  production: false,
  firebase: {
    apiKey: "AIzaSyBrsHUpLMnQRBJZQsoeoTblxC0i6hrg464",
    authDomain: "tasktrack-d6a15.firebaseapp.com",
    projectId: "tasktrack-d6a15",
    storageBucket: "tasktrack-d6a15.firebasestorage.app",
    messagingSenderId: "56586019259",
    appId: "1:56586019259:web:9aaedc53cd4ba8aba9e49e",
    measurementId: "G-NR41Z45BSX"
  }
};
