import { Component, Input, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { 
  ModalController,
  IonHeader,
  IonToolbar,
  IonTitle,
  IonButtons,
  IonButton,
  IonIcon,
  IonContent,
  IonItem,
  IonLabel,
  IonInput,
  IonTextarea,
  IonSegment,
  IonSegmentButton,
  IonGrid,
  IonRow,
  IonCol
} from '@ionic/angular/standalone';
import { Task } from '../../services/task.service';

@Component({
  selector: 'app-task-modal',
  templateUrl: './task-edit-modal.component.html',
  styleUrls: ['./task-edit-modal.component.scss'],
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    IonHeader,
    IonToolbar,
    IonTitle,
    IonButtons,
    IonButton,
    IonIcon,
    IonContent,
    IonItem,
    IonLabel,
    IonInput,
    IonTextarea,
    IonSegment,
    IonSegmentButton,
    IonGrid,
    IonRow,
    IonCol
  ]
})
export class TaskModalComponent implements OnInit {
  @Input() task?: Task;
  @Input() mode: 'add' | 'edit' = 'add';

  taskData = {
    title: '',
    description: '',
    dueDate: '',
    priority: 'medium' as 'low' | 'medium' | 'high',
    status: 'pending' as 'pending' | 'completed' | 'overdue'
  };

  priorities = [
    { value: 'low', label: 'Low', color: 'success' },
    { value: 'medium', label: 'Medium', color: 'warning' },
    { value: 'high', label: 'High', color: 'danger' }
  ];

  constructor(private modalController: ModalController) {}

  ngOnInit() {
    if (this.task && this.mode === 'edit') {
      this.taskData = {
        title: this.task.title,
        description: this.task.description,
        dueDate: this.task.dueDate,
        priority: this.task.priority,
        status: this.task.status
      };
    } else {
      // Set default due date to tomorrow
      const tomorrow = new Date();
      tomorrow.setDate(tomorrow.getDate() + 1);
      this.taskData.dueDate = tomorrow.toISOString().split('T')[0];
    }
  }

  // Save task
  saveTask() {
    if (this.taskData.title.trim()) {
      this.modalController.dismiss({
        task: this.taskData,
        mode: this.mode,
        originalTask: this.task
      });
    }
  }

  // Cancel modal
  cancel() {
    this.modalController.dismiss();
  }

  // Get priority color
  getPriorityColor(priority: string): string {
    const priorityObj = this.priorities.find(p => p.value === priority);
    return priorityObj ? priorityObj.color : 'medium';
  }
}