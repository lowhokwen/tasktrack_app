import { Injectable } from '@angular/core';
import { Task } from './services/task.service';

@Injectable({
  providedIn: 'root'
})
export class SimpleStorageService {

  // Save tasks to local storage
  saveTasks(tasks: Task[]): void {
    localStorage.setItem('tasks', JSON.stringify(tasks));
    localStorage.setItem('tasks_last_updated', new Date().toISOString());
  }

  // Load tasks from local storage
  loadTasks(): Task[] {
    const tasks = localStorage.getItem('tasks');
    return tasks ? JSON.parse(tasks) : [];
  }

  // Get last update time
  getLastUpdateTime(): string {
    return localStorage.getItem('tasks_last_updated') || '';
  }

  // Clear all cached data
  clearCache(): void {
    localStorage.removeItem('tasks');
    localStorage.removeItem('tasks_last_updated');
  }

  // Save user settings
  saveSettings(settings: any): void {
    localStorage.setItem('user_settings', JSON.stringify(settings));
  }

  // Load user settings
  loadSettings(): any {
    const settings = localStorage.getItem('user_settings');
    return settings ? JSON.parse(settings) : {
      theme: 'light',
      notifications: true
    };
  }

  // Save login state
  saveLoginState(isLoggedIn: boolean): void {
    localStorage.setItem('is_logged_in', JSON.stringify(isLoggedIn));
  }

  // Load login state
  loadLoginState(): boolean {
    const loginState = localStorage.getItem('is_logged_in');
    return loginState ? JSON.parse(loginState) : false;
  }
}